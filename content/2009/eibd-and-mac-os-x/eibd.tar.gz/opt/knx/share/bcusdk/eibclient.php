<?php
/*
    EIBD client library
    Copyright (C) 2005-2009 Martin Koegler <mkoegler@auto.tuwien.ac.at>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    In addition to the permissions in the GNU General Public License, 
    you may link the compiled version of this file into combinations
    with other programs, and distribute those combinations without any 
    restriction coming from the use of this file. (The General Public 
    License restrictions do apply in other respects; for example, they 
    cover modification of the file, and distribution when not linked into 
    a combine executable.)

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
class           EIBBuffer {
	public $buffer;
	function        _construct($buf = "") {
		$this->buffer = $buf;
	}
}
class           EIBAddr {
	public $addr;
	function        _construct($a = 0) {
		$this->addr = $a;
	}
}
class           EIBInt8 {
	public $data;
	function        _construct($val = 0) {
		$this->val = $a;
	}
}
class           EIBInt16 {
	public $data;
	function        _construct($val = 0) {
		$this->val = $a;
	}
}


class           EIBConnection {
	const           EINVAL = 1;
	const           ECONNRESET = 2;
	const           EBUSY = 3;
	const           EADDRINUSE = 4;
	const           ETIMEDOUT = 5;
	const           EADDRNOTAVAIL = 6;
	const           EIO = 7;
	const           EPERM = 8;
	const           ENOENT = 9;
	const           ENODEV = 10;
	const           EBADF = 11;
	                private $errno = 0;
	public function getLastError() {
		return $this->errno;
	}
	                private $buf;
	                private $ptr1;
	                private $ptr2;
	                private $ptr3;
	                private $ptr4;
	                private $ptr5;
	                private $ptr6;
	                private $sendlen;
	                private $complete;
	public function EIBComplete() {
		$name = $this->complete;
		return $this->$name();
	}
	                private $data;
	                private $head;
	                private $readlen;
	                private $datalen;
	                private $socket;
	function        __construct($host, $port = 6720) {
		$this->readlen = 0;
		$this->socket = stream_socket_client("tcp://".$host.":".$port);
		if ($this->socket === FALSE)
			throw new       Exception("connect failed");
	}
	private function _EIB_SendRequest($data) {
		if ($this->socket === FALSE) {
			$this->errno = self::ECONNRESET;
			return -1;
		}
		if (strlen($data) > 0xffff || strlen($data) < 2) {
	$this->errno = self: :EINVAL;
			return -1;
		}
		                $len = pack("n", strlen($data));
		if              (fwrite($this->socket, $len.$data) != strlen($data) + 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}
		                return 0;
	}
	private function _EIB_CheckRequest($block) {
		if ($this->socket === FALSE || feof($this->socket)) {
			$this->errno = self::ECONNRESET;
			return -1;
		}
		if ($this->readlen == 0) {
			$this->head = array(" ", " ");
			$this->data = array();
		}
		if              ($this->readlen < 2) {
			stream_set_blocking($this->socket, $block ? 1 : 0);
			$read = fread($this->socket, 2 - $this->readlen);
			if ($read === FALSE) {
		$this->errno = self: :ECONNRESET;
				return -1;
			}
			for ($i = 0; $i < strlen($read); $i++)
				$this->head[$this->readlen++] = substr($read, $i, 1);
		}
		if ($this->readlen < 2)
			return 0;
$this->datalen = EIBConnection: :upack(implode("", $this->head), "n");
		if (feof($this->socket)) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}
		if ($this->readlen < $this->datalen + 2) {
			stream_set_blocking($this->socket, $block ? 1 : 0);
			$read = fread($this->socket, $this->datalen + 2 - $this->readlen);
			if ($read === FALSE) {
		$this->errno = self: :ECONNRESET;
				return -1;
			}
			for ($i = 0; $i < strlen($read); $i++)
				$this->data[($this->readlen++) - 2] = substr($read, $i, 1);
		}
		return 0;
	}
	private function _EIB_GetRequest() {
		do {
			if ($this->_EIB_CheckRequest(true) == -1)
				return -1;
		}
		while ($this->readlen < 2 || ($this->readlen >= 2 && $this->readlen < $this->datalen + 2));
		$this->data = implode("", $this->data);
		$this->readlen = 0;
		return 0;
	}
	public function EIB_Poll_Complete() {
		if ($this->_EIB_CheckRequest(false) == -1)
			return -1;
		if ($this->readlen < 2 || ($this->readlen >= 2 && $this->readlen < $this->datalen + 2))
			return 0;
		return 1;
	}
	public function EIBClose() {
		if ($socket === FALSE) {
			$this->errno = self::EBADF;
			return -1;
		}
		fclose($this->socket);
		$this->socket = FALSE;
	}
	public function EIBClose_sync() {
		$this->EIBReset();
		return $this->EIBClose();
	}


	private function EIBGetAPDU_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0025 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               $this->buf->buffer = substr($this->data, 2);
		return strlen($this->buf->buffer);
	}
	public function EIBGetAPDU_async(EIBBuffer PAR(buf)) {
		$head = array();
		for ($i = 0; $i < 2; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
		$this->buf = PAR(buf);
		$this->complete = "EIBGetAPDU"."_complete";
		return 0;
	} public function EIBGetAPDU(EIBBuffer PAR(buf)) {
		if ($this->EIBGetAPDU_async(PAR(buf)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIBGetAPDU_Src_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0025 || strlen($this->data) < 4) {
	$this->errno = self: :ECONNRESET;
			return -1;
		} if            ($this->ptr5 != null)
	                $this->ptr5->addr = (EIBConnection: :                upack(substr(substr($this->data, 2), 0, 2), "n"));
		$this->buf->buffer = substr($this->data, 4);
		return strlen($this->buf->buffer);
	}
	public function EIBGetAPDU_Src_async(EIBBuffer PAR(buf), EIBAddr PAR(src)) {
		$head = array();
		for ($i = 0; $i < 2; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
		$this->buf = PAR(buf);
		$this->ptr5 = PAR(src);
		$this->complete = "EIBGetAPDU_Src"."_complete";
		return 0;
	} public function EIBGetAPDU_Src(EIBBuffer PAR(buf), EIBAddr PAR(src)) {
		if ($this->EIBGetAPDU_Src_async(PAR(buf), PAR(src)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIBGetBusmonitorPacket_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0014 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               $this->buf->buffer = substr($this->data, 2);
		return strlen($this->buf->buffer);
	}
	public function EIBGetBusmonitorPacket_async(EIBBuffer PAR(buf)) {
		$head = array();
		for ($i = 0; $i < 2; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
		$this->buf = PAR(buf);
		$this->complete = "EIBGetBusmonitorPacket"."_complete";
		return 0;
	} public function EIBGetBusmonitorPacket(EIBBuffer PAR(buf)) {
		if ($this->EIBGetBusmonitorPacket_async(PAR(buf)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIBGetGroup_Src_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0027 || strlen($this->data) < 6) {
	$this->errno = self: :ECONNRESET;
			return -1;
		} if            ($this->ptr5 != null)
	                $this->ptr5->addr = (EIBConnection: :                upack(substr(substr($this->data, 2), 0, 2), "n"));
		if ($this->ptr6 != null)
	$this->ptr6->addr = (EIBConnection: :upack(substr(substr($this->data, 4), 0, 2), "n"));
		$this->buf->buffer = substr($this->data, 6);
		return strlen($this->buf->buffer);
	}
	public function EIBGetGroup_Src_async(EIBBuffer PAR(buf), EIBAddr PAR(src), EIBAddr PAR(dest)) {
		$head = array();
		for ($i = 0; $i < 2; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
		$this->buf = PAR(buf);
		$this->ptr5 = PAR(src);
		$this->ptr6 = PAR(dest);
		$this->complete = "EIBGetGroup_Src"."_complete";
		return 0;
	} public function EIBGetGroup_Src(EIBBuffer PAR(buf), EIBAddr PAR(src), EIBAddr PAR(dest)) {
		if ($this->EIBGetGroup_Src_async(PAR(buf), PAR(src), PAR(dest)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIBGetTPDU_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0025 || strlen($this->data) < 4) {
	$this->errno = self: :ECONNRESET;
			return -1;
		} if            ($this->ptr5 != null)
	                $this->ptr5->addr = (EIBConnection: :                upack(substr(substr($this->data, 2), 0, 2), "n"));
		$this->buf->buffer = substr($this->data, 4);
		return strlen($this->buf->buffer);
	}
	public function EIBGetTPDU_async(EIBBuffer PAR(buf), EIBAddr PAR(src)) {
		$head = array();
		for ($i = 0; $i < 2; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
		$this->buf = PAR(buf);
		$this->ptr5 = PAR(src);
		$this->complete = "EIBGetTPDU"."_complete";
		return 0;
	} public function EIBGetTPDU(EIBBuffer PAR(buf), EIBAddr PAR(src)) {
		if ($this->EIBGetTPDU_async(PAR(buf), PAR(src)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_Cache_Clear_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0072 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               return 0;
	}
	public function EIB_Cache_Clear_async() {
		$head = array();
		for ($i = 0; $i < 2; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[0] = EIBConnection: :packb((0x0072 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0072) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_Cache_Clear"."_complete";
		return 0;
	} public function EIB_Cache_Clear() {
		if ($this->EIB_Cache_Clear_async() == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_Cache_Disable_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0071 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               return 0;
	}
	public function EIB_Cache_Disable_async() {
		$head = array();
		for ($i = 0; $i < 2; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[0] = EIBConnection: :packb((0x0071 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0071) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_Cache_Disable"."_complete";
		return 0;
	} public function EIB_Cache_Disable() {
		if ($this->EIB_Cache_Disable_async() == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_Cache_Enable_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) == 0x0001) {
	$this->errno = self: :EBUSY;
			return -1;
} if            (((EIBConnection: :                upack(substr($this->data, 0, 2), "n"))) != 0x0070 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		} return 0;
	}
	public function EIB_Cache_Enable_async() {
		$head = array();
		for ($i = 0; $i < 2; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[0] = EIBConnection: :packb((0x0070 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0070) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_Cache_Enable"."_complete";
		return 0;
	} public function EIB_Cache_Enable() {
		if ($this->EIB_Cache_Enable_async() == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_Cache_Read_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0075 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
} if            ((EIBConnection: :                upack(substr(substr($this->data, 4), 0, 2), "n")) == 0) {
	$this->errno = self: :ENODEV;
			return -1;
		} if (strlen($this->data) <= 6) {
	$this->errno = self: :ENOENT;
			return -1;
		} if ($this->ptr5 != null)
	$this->ptr5->addr = (EIBConnection: :upack(substr(substr($this->data, 2), 0, 2), "n"));
		$this->buf->buffer = substr($this->data, 6);
		return strlen($this->buf->buffer);
	}
	public function EIB_Cache_Read_async(PAR(dst), EIBAddr PAR(src), EIBBuffer PAR(buf)) {
		$head = array();
		for ($i = 0; $i < 4; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
		$this->buf = PAR(buf);
		$this->ptr5 = PAR(src);
$ibuf[2] = EIBConnection: :packb((PAR(dst) >> 8) & 0xff);
$ibuf[2 + 1] = EIBConnection: :packb((PAR(dst)) & 0xff);
$ibuf[0] = EIBConnection: :packb((0x0075 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0075) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_Cache_Read"."_complete";
		return 0;
	} public function EIB_Cache_Read(PAR(dst), EIBAddr PAR(src), EIBBuffer PAR(buf)) {
		if ($this->EIB_Cache_Read_async(PAR(dst), PAR(src), PAR(buf)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_Cache_Read_Sync_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0074 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
} if            ((EIBConnection: :                upack(substr(substr($this->data, 4), 0, 2), "n")) == 0) {
	$this->errno = self: :ENODEV;
			return -1;
		} if (strlen($this->data) <= 6) {
	$this->errno = self: :ENOENT;
			return -1;
		} if ($this->ptr5 != null)
	$this->ptr5->addr = (EIBConnection: :upack(substr(substr($this->data, 2), 0, 2), "n"));
		$this->buf->buffer = substr($this->data, 6);
		return strlen($this->buf->buffer);
	}
	public function EIB_Cache_Read_Sync_async(PAR(dst), EIBAddr PAR(src), EIBBuffer PAR(buf), PAR(age)) {
		$head = array();
		for ($i = 0; $i < 6; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
		$this->buf = PAR(buf);
		$this->ptr5 = PAR(src);
$ibuf[2] = EIBConnection: :packb((PAR(dst) >> 8) & 0xff);
$ibuf[2 + 1] = EIBConnection: :packb((PAR(dst)) & 0xff);
$ibuf[4] = EIBConnection: :packb((PAR(age) >> 8) & 0xff);
$ibuf[4 + 1] = EIBConnection: :packb((PAR(age)) & 0xff);
$ibuf[0] = EIBConnection: :packb((0x0074 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0074) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_Cache_Read_Sync"."_complete";
		return 0;
	} public function EIB_Cache_Read_Sync(PAR(dst), EIBAddr PAR(src), EIBBuffer PAR(buf), PAR(age)) {
		if ($this->EIB_Cache_Read_Sync_async(PAR(dst), PAR(src), PAR(buf), PAR(age)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_Cache_Remove_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0073 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               return 0;
	}
	public function EIB_Cache_Remove_async(PAR(dest)) {
		$head = array();
		for ($i = 0; $i < 4; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[2] = EIBConnection: :packb((PAR(dest) >> 8) & 0xff);
$ibuf[2 + 1] = EIBConnection: :packb((PAR(dest)) & 0xff);
$ibuf[0] = EIBConnection: :packb((0x0073 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0073) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_Cache_Remove"."_complete";
		return 0;
	} public function EIB_Cache_Remove(PAR(dest)) {
		if ($this->EIB_Cache_Remove_async(PAR(dest)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_LoadImage_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0063 || strlen($this->data) < 4) {
	$this->errno = self: :ECONNRESET;
			return -1;
}               return (EIBConnection: :                upack(substr(substr($this->data, 2), 0, 2), "n"));
	}
	public function EIB_LoadImage_async(PAR(image)) {
		$head = array();
		for ($i = 0; $i < 2; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
		if (strlen(PAR(image)) < 0) {
	$this->errno = self: :EINVAL;
			return -1;
		}               $this->sendlen = strlen(PAR(image));
		for ($i = 0; $i < strlen(PAR(image)); $i++)
			$ibuf[] = substr(PAR(image), $i, 1);
$ibuf[0] = EIBConnection: :packb((0x0063 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0063) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_LoadImage"."_complete";
		return 0;
	} public function EIB_LoadImage(PAR(image)) {
		if ($this->EIB_LoadImage_async(PAR(image)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_MC_Authorize_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0057 || strlen($this->data) < 3) {
	$this->errno = self: :ECONNRESET;
			return -1;
}               return (EIBConnection: :                upack(substr(substr($this->data, 2), 0, 1), "C"));
	}
	public function EIB_MC_Authorize_async(PAR(key)) {
		$head = array();
		for ($i = 0; $i < 6; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
		if (strlen(PAR(key)) != 4) {
	$this->errno = self: :EINVAL;
			return -1;
		} for           ($i = 0; $i < 4; $i++)
			$ibuf[2 + $i] = substr(PAR(key), $i, 1);
$ibuf[0] = EIBConnection: :packb((0x0057 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0057) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_MC_Authorize"."_complete";
		return 0;
	} public function EIB_MC_Authorize(PAR(key)) {
		if ($this->EIB_MC_Authorize_async(PAR(key)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_MC_Connect_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0050 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               return 0;
	}
	public function EIB_MC_Connect_async(PAR(dest)) {
		$head = array();
		for ($i = 0; $i < 4; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[2] = EIBConnection: :packb((PAR(dest) >> 8) & 0xff);
$ibuf[2 + 1] = EIBConnection: :packb((PAR(dest)) & 0xff);
$ibuf[0] = EIBConnection: :packb((0x0050 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0050) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_MC_Connect"."_complete";
		return 0;
	} public function EIB_MC_Connect(PAR(dest)) {
		if ($this->EIB_MC_Connect_async(PAR(dest)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_MC_GetMaskVersion_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0059 || strlen($this->data) < 4) {
	$this->errno = self: :ECONNRESET;
			return -1;
}               return (EIBConnection: :                upack(substr(substr($this->data, 2), 0, 2), "n"));
	}
	public function EIB_MC_GetMaskVersion_async() {
		$head = array();
		for ($i = 0; $i < 2; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[0] = EIBConnection: :packb((0x0059 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0059) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_MC_GetMaskVersion"."_complete";
		return 0;
	} public function EIB_MC_GetMaskVersion() {
		if ($this->EIB_MC_GetMaskVersion_async() == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_MC_GetPEIType_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0055 || strlen($this->data) < 4) {
	$this->errno = self: :ECONNRESET;
			return -1;
}               return (EIBConnection: :                upack(substr(substr($this->data, 2), 0, 2), "n"));
	}
	public function EIB_MC_GetPEIType_async() {
		$head = array();
		for ($i = 0; $i < 2; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[0] = EIBConnection: :packb((0x0055 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0055) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_MC_GetPEIType"."_complete";
		return 0;
	} public function EIB_MC_GetPEIType() {
		if ($this->EIB_MC_GetPEIType_async() == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_MC_Progmode_Off_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0060 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               return 0;
	}
	public function EIB_MC_Progmode_Off_async() {
		$head = array();
		for ($i = 0; $i < 3; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[2] = EIBConnection: :packb((PAR(0)) & 0xff);
$ibuf[0] = EIBConnection: :packb((0x0060 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0060) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_MC_Progmode_Off"."_complete";
		return 0;
	} public function EIB_MC_Progmode_Off() {
		if ($this->EIB_MC_Progmode_Off_async() == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_MC_Progmode_On_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0060 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               return 0;
	}
	public function EIB_MC_Progmode_On_async() {
		$head = array();
		for ($i = 0; $i < 3; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[2] = EIBConnection: :packb((PAR(1)) & 0xff);
$ibuf[0] = EIBConnection: :packb((0x0060 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0060) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_MC_Progmode_On"."_complete";
		return 0;
	} public function EIB_MC_Progmode_On() {
		if ($this->EIB_MC_Progmode_On_async() == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_MC_Progmode_Status_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0060 || strlen($this->data) < 3) {
	$this->errno = self: :ECONNRESET;
			return -1;
}               return (EIBConnection: :                upack(substr(substr($this->data, 2), 0, 1), "C"));
	}
	public function EIB_MC_Progmode_Status_async() {
		$head = array();
		for ($i = 0; $i < 3; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[2] = EIBConnection: :packb((PAR(3)) & 0xff);
$ibuf[0] = EIBConnection: :packb((0x0060 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0060) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_MC_Progmode_Status"."_complete";
		return 0;
	} public function EIB_MC_Progmode_Status() {
		if ($this->EIB_MC_Progmode_Status_async() == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_MC_Progmode_Toggle_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0060 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               return 0;
	}
	public function EIB_MC_Progmode_Toggle_async() {
		$head = array();
		for ($i = 0; $i < 3; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[2] = EIBConnection: :packb((PAR(2)) & 0xff);
$ibuf[0] = EIBConnection: :packb((0x0060 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0060) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_MC_Progmode_Toggle"."_complete";
		return 0;
	} public function EIB_MC_Progmode_Toggle() {
		if ($this->EIB_MC_Progmode_Toggle_async() == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_MC_PropertyDesc_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0061 || strlen($this->data) < 6) {
	$this->errno = self: :ECONNRESET;
			return -1;
		} if            ($this->ptr2 != null)
	                $this->ptr2->data = (EIBConnection: :                upack(substr(substr($this->data, 2), 0, 1), "C"));
		if ($this->ptr4 != null)
	$this->ptr4->data = (EIBConnection: :upack(substr(substr($this->data, 3), 0, 2), "n"));
		if ($this->ptr3 != null)
	$this->ptr3->data = (EIBConnection: :upack(substr(substr($this->data, 5), 0, 1), "C"));
		return 0;
	}
	public function EIB_MC_PropertyDesc_async(PAR(obj), PAR(property), EIBInt8 PAR(type), EIBInt16 PAR(max_nr_of_elem), EIBInt8 PAR(access)) {
		$head = array();
		for ($i = 0; $i < 4; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
		$this->ptr2 = PAR(type);
		$this->ptr4 = PAR(max_nr_of_elem);
		$this->ptr3 = PAR(access);
$ibuf[2] = EIBConnection: :packb((PAR(obj)) & 0xff);
$ibuf[3] = EIBConnection: :packb((PAR(property)) & 0xff);
$ibuf[0] = EIBConnection: :packb((0x0061 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0061) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_MC_PropertyDesc"."_complete";
		return 0;
	} public function EIB_MC_PropertyDesc(PAR(obj), PAR(property), EIBInt8 PAR(type), EIBInt16 PAR(max_nr_of_elem), EIBInt8 PAR(access)) {
		if ($this->EIB_MC_PropertyDesc_async(PAR(obj), PAR(property), PAR(type), PAR(max_nr_of_elem), PAR(access)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_MC_PropertyRead_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0053 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               $this->buf->buffer = substr($this->data, 2);
		return strlen($this->buf->buffer);
	}
	public function EIB_MC_PropertyRead_async(PAR(obj), PAR(property), PAR(start), PAR(nr_of_elem), EIBBuffer PAR(buf)) {
		$head = array();
		for ($i = 0; $i < 7; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
		$this->buf = PAR(buf);
$ibuf[2] = EIBConnection: :packb((PAR(obj)) & 0xff);
$ibuf[3] = EIBConnection: :packb((PAR(property)) & 0xff);
$ibuf[4] = EIBConnection: :packb((PAR(start) >> 8) & 0xff);
$ibuf[4 + 1] = EIBConnection: :packb((PAR(start)) & 0xff);
$ibuf[6] = EIBConnection: :packb((PAR(nr_of_elem)) & 0xff);
$ibuf[0] = EIBConnection: :packb((0x0053 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0053) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_MC_PropertyRead"."_complete";
		return 0;
	} public function EIB_MC_PropertyRead(PAR(obj), PAR(property), PAR(start), PAR(nr_of_elem), EIBBuffer PAR(buf)) {
		if ($this->EIB_MC_PropertyRead_async(PAR(obj), PAR(property), PAR(start), PAR(nr_of_elem), PAR(buf)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_MC_PropertyScan_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0062 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               $this->buf->buffer = substr($this->data, 2);
		return strlen($this->buf->buffer);
	}
	public function EIB_MC_PropertyScan_async(EIBBuffer PAR(buf)) {
		$head = array();
		for ($i = 0; $i < 2; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
		$this->buf = PAR(buf);
$ibuf[0] = EIBConnection: :packb((0x0062 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0062) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_MC_PropertyScan"."_complete";
		return 0;
	} public function EIB_MC_PropertyScan(EIBBuffer PAR(buf)) {
		if ($this->EIB_MC_PropertyScan_async(PAR(buf)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_MC_PropertyWrite_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0054 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               $this->buf->buffer = substr($this->data, 2);
		return strlen($this->buf->buffer);
	}
	public function EIB_MC_PropertyWrite_async(PAR(obj), PAR(property), PAR(start), PAR(nr_of_elem), PAR(buf), EIBBuffer PAR(res)) {
		$head = array();
		for ($i = 0; $i < 7; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[2] = EIBConnection: :packb((PAR(obj)) & 0xff);
$ibuf[3] = EIBConnection: :packb((PAR(property)) & 0xff);
$ibuf[4] = EIBConnection: :packb((PAR(start) >> 8) & 0xff);
$ibuf[4 + 1] = EIBConnection: :packb((PAR(start)) & 0xff);
$ibuf[6] = EIBConnection: :packb((PAR(nr_of_elem)) & 0xff);
		if (strlen(PAR(buf)) < 0) {
	$this->errno = self: :EINVAL;
			return -1;
		}               $this->sendlen = strlen(PAR(buf));
		for ($i = 0; $i < strlen(PAR(buf)); $i++)
			$ibuf[] = substr(PAR(buf), $i, 1);
		$this->buf = PAR(res);
$ibuf[0] = EIBConnection: :packb((0x0054 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0054) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_MC_PropertyWrite"."_complete";
		return 0;
	} public function EIB_MC_PropertyWrite(PAR(obj), PAR(property), PAR(start), PAR(nr_of_elem), PAR(buf), EIBBuffer PAR(res)) {
		if ($this->EIB_MC_PropertyWrite_async(PAR(obj), PAR(property), PAR(start), PAR(nr_of_elem), PAR(buf), PAR(res)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_MC_ReadADC_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0056 || strlen($this->data) < 4) {
	$this->errno = self: :ECONNRESET;
			return -1;
		} if            ($this->ptr1 != null)
	                $this->ptr1->data = (EIBConnection: :                upack(substr(substr($this->data, 2), 0, 2), "n"));
		return 0;
	}
	public function EIB_MC_ReadADC_async(PAR(channel), PAR(count), EIBInt16 PAR(val)) {
		$head = array();
		for ($i = 0; $i < 4; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
		$this->ptr1 = PAR(val);
$ibuf[2] = EIBConnection: :packb((PAR(channel)) & 0xff);
$ibuf[3] = EIBConnection: :packb((PAR(count)) & 0xff);
$ibuf[0] = EIBConnection: :packb((0x0056 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0056) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_MC_ReadADC"."_complete";
		return 0;
	} public function EIB_MC_ReadADC(PAR(channel), PAR(count), EIBInt16 PAR(val)) {
		if ($this->EIB_MC_ReadADC_async(PAR(channel), PAR(count), PAR(val)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_MC_Read_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0051 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               $this->buf->buffer = substr($this->data, 2);
		return strlen($this->buf->buffer);
	}
	public function EIB_MC_Read_async(PAR(addr), PAR(buf_len), EIBBuffer PAR(buf)) {
		$head = array();
		for ($i = 0; $i < 6; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
		$this->buf = PAR(buf);
$ibuf[2] = EIBConnection: :packb((PAR(addr) >> 8) & 0xff);
$ibuf[2 + 1] = EIBConnection: :packb((PAR(addr)) & 0xff);
$ibuf[4] = EIBConnection: :packb((PAR((PAR(buf_len))) >> 8) & 0xff);
$ibuf[4 + 1] = EIBConnection: :packb((PAR((PAR(buf_len)))) & 0xff);
$ibuf[0] = EIBConnection: :packb((0x0051 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0051) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_MC_Read"."_complete";
		return 0;
	} public function EIB_MC_Read(PAR(addr), PAR(buf_len), EIBBuffer PAR(buf)) {
		if ($this->EIB_MC_Read_async(PAR(addr), PAR(buf_len), $name) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_MC_Restart_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x005a || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               return 0;
	}
	public function EIB_MC_Restart_async() {
		$head = array();
		for ($i = 0; $i < 2; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[0] = EIBConnection: :packb((0x005a >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x005a) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_MC_Restart"."_complete";
		return 0;
	} public function EIB_MC_Restart() {
		if ($this->EIB_MC_Restart_async() == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_MC_SetKey_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) == 0x0002) {
	$this->errno = self: :EPERM;
			return -1;
} if            (((EIBConnection: :                upack(substr($this->data, 0, 2), "n"))) != 0x0058 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		} return 0;
	}
	public function EIB_MC_SetKey_async(PAR(key), PAR(level)) {
		$head = array();
		for ($i = 0; $i < 7; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
		if (strlen(PAR(key)) != 4) {
	$this->errno = self: :EINVAL;
			return -1;
		} for           ($i = 0; $i < 4; $i++)
			$ibuf[2 + $i] = substr(PAR(key), $i, 1);
$ibuf[6] = EIBConnection: :packb((PAR(level)) & 0xff);
$ibuf[0] = EIBConnection: :packb((0x0058 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0058) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_MC_SetKey"."_complete";
		return 0;
	} public function EIB_MC_SetKey(PAR(key), PAR(level)) {
		if ($this->EIB_MC_SetKey_async(PAR(key), PAR(level)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_MC_Write_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) == 0x0044) {
	$this->errno = self: :EIO;
			return -1;
} if            (((EIBConnection: :                upack(substr($this->data, 0, 2), "n"))) != 0x0052 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		} return $this->sendlen;
	}
	public function EIB_MC_Write_async(PAR(addr), PAR(buf)) {
		$head = array();
		for ($i = 0; $i < 6; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[2] = EIBConnection: :packb((PAR(addr) >> 8) & 0xff);
$ibuf[2 + 1] = EIBConnection: :packb((PAR(addr)) & 0xff);
$ibuf[4] = EIBConnection: :packb((PAR((strlen(PAR(buf)))) >> 8) & 0xff);
$ibuf[4 + 1] = EIBConnection: :packb((PAR((strlen(PAR(buf))))) & 0xff);
		if (strlen(PAR(buf)) < 0) {
	$this->errno = self: :EINVAL;
			return -1;
		}               $this->sendlen = strlen(PAR(buf));
		for ($i = 0; $i < strlen(PAR(buf)); $i++)
			$ibuf[] = substr(PAR(buf), $i, 1);
$ibuf[0] = EIBConnection: :packb((0x0052 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0052) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_MC_Write"."_complete";
		return 0;
	} public function EIB_MC_Write(PAR(addr), PAR(buf)) {
		if ($this->EIB_MC_Write_async(PAR(addr), PAR(buf)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_MC_Write_Plain_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x005b || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               return $this->sendlen;
	}
	public function EIB_MC_Write_Plain_async(PAR(addr), PAR(buf)) {
		$head = array();
		for ($i = 0; $i < 6; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[2] = EIBConnection: :packb((PAR(addr) >> 8) & 0xff);
$ibuf[2 + 1] = EIBConnection: :packb((PAR(addr)) & 0xff);
$ibuf[4] = EIBConnection: :packb((PAR((strlen(PAR(buf)))) >> 8) & 0xff);
$ibuf[4 + 1] = EIBConnection: :packb((PAR((strlen(PAR(buf))))) & 0xff);
		if (strlen(PAR(buf)) < 0) {
	$this->errno = self: :EINVAL;
			return -1;
		}               $this->sendlen = strlen(PAR(buf));
		for ($i = 0; $i < strlen(PAR(buf)); $i++)
			$ibuf[] = substr(PAR(buf), $i, 1);
$ibuf[0] = EIBConnection: :packb((0x005b >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x005b) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_MC_Write_Plain"."_complete";
		return 0;
	} public function EIB_MC_Write_Plain(PAR(addr), PAR(buf)) {
		if ($this->EIB_MC_Write_Plain_async(PAR(addr), PAR(buf)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_M_GetMaskVersion_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0031 || strlen($this->data) < 4) {
	$this->errno = self: :ECONNRESET;
			return -1;
}               return (EIBConnection: :                upack(substr(substr($this->data, 2), 0, 2), "n"));
	}
	public function EIB_M_GetMaskVersion_async(PAR(dest)) {
		$head = array();
		for ($i = 0; $i < 4; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[2] = EIBConnection: :packb((PAR(dest) >> 8) & 0xff);
$ibuf[2 + 1] = EIBConnection: :packb((PAR(dest)) & 0xff);
$ibuf[0] = EIBConnection: :packb((0x0031 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0031) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_M_GetMaskVersion"."_complete";
		return 0;
	} public function EIB_M_GetMaskVersion(PAR(dest)) {
		if ($this->EIB_M_GetMaskVersion_async(PAR(dest)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_M_Progmode_Off_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0030 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               return 0;
	}
	public function EIB_M_Progmode_Off_async(PAR(dest)) {
		$head = array();
		for ($i = 0; $i < 5; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[2] = EIBConnection: :packb((PAR(dest) >> 8) & 0xff);
$ibuf[2 + 1] = EIBConnection: :packb((PAR(dest)) & 0xff);
$ibuf[4] = EIBConnection: :packb((PAR(0)) & 0xff);
$ibuf[0] = EIBConnection: :packb((0x0030 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0030) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_M_Progmode_Off"."_complete";
		return 0;
	} public function EIB_M_Progmode_Off(PAR(dest)) {
		if ($this->EIB_M_Progmode_Off_async(PAR(dest)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_M_Progmode_On_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0030 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               return 0;
	}
	public function EIB_M_Progmode_On_async(PAR(dest)) {
		$head = array();
		for ($i = 0; $i < 5; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[2] = EIBConnection: :packb((PAR(dest) >> 8) & 0xff);
$ibuf[2 + 1] = EIBConnection: :packb((PAR(dest)) & 0xff);
$ibuf[4] = EIBConnection: :packb((PAR(1)) & 0xff);
$ibuf[0] = EIBConnection: :packb((0x0030 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0030) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_M_Progmode_On"."_complete";
		return 0;
	} public function EIB_M_Progmode_On(PAR(dest)) {
		if ($this->EIB_M_Progmode_On_async(PAR(dest)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_M_Progmode_Status_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0030 || strlen($this->data) < 3) {
	$this->errno = self: :ECONNRESET;
			return -1;
}               return (EIBConnection: :                upack(substr(substr($this->data, 2), 0, 1), "C"));
	}
	public function EIB_M_Progmode_Status_async(PAR(dest)) {
		$head = array();
		for ($i = 0; $i < 5; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[2] = EIBConnection: :packb((PAR(dest) >> 8) & 0xff);
$ibuf[2 + 1] = EIBConnection: :packb((PAR(dest)) & 0xff);
$ibuf[4] = EIBConnection: :packb((PAR(3)) & 0xff);
$ibuf[0] = EIBConnection: :packb((0x0030 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0030) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_M_Progmode_Status"."_complete";
		return 0;
	} public function EIB_M_Progmode_Status(PAR(dest)) {
		if ($this->EIB_M_Progmode_Status_async(PAR(dest)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_M_Progmode_Toggle_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0030 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               return 0;
	}
	public function EIB_M_Progmode_Toggle_async(PAR(dest)) {
		$head = array();
		for ($i = 0; $i < 5; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[2] = EIBConnection: :packb((PAR(dest) >> 8) & 0xff);
$ibuf[2 + 1] = EIBConnection: :packb((PAR(dest)) & 0xff);
$ibuf[4] = EIBConnection: :packb((PAR(2)) & 0xff);
$ibuf[0] = EIBConnection: :packb((0x0030 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0030) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_M_Progmode_Toggle"."_complete";
		return 0;
	} public function EIB_M_Progmode_Toggle(PAR(dest)) {
		if ($this->EIB_M_Progmode_Toggle_async(PAR(dest)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_M_ReadIndividualAddresses_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0032 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               $this->buf->buffer = substr($this->data, 2);
		return strlen($this->buf->buffer);
	}
	public function EIB_M_ReadIndividualAddresses_async(EIBBuffer PAR(buf)) {
		$head = array();
		for ($i = 0; $i < 2; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
		$this->buf = PAR(buf);
$ibuf[0] = EIBConnection: :packb((0x0032 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0032) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_M_ReadIndividualAddresses"."_complete";
		return 0;
	} public function EIB_M_ReadIndividualAddresses(EIBBuffer PAR(buf)) {
		if ($this->EIB_M_ReadIndividualAddresses_async(PAR(buf)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIB_M_WriteIndividualAddress_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) == 0x0041) {
	$this->errno = self: :EADDRINUSE;
			return -1;
} if            (((EIBConnection: :                upack(substr($this->data, 0, 2), "n"))) == 0x0043) {
	$this->errno = self: :ETIMEDOUT;
			return -1;
} if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) == 0x0042) {
	$this->errno = self: :EADDRNOTAVAIL;
			return -1;
} if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0040 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		} return 0;
	}
	public function EIB_M_WriteIndividualAddress_async(PAR(dest)) {
		$head = array();
		for ($i = 0; $i < 4; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[2] = EIBConnection: :packb((PAR(dest) >> 8) & 0xff);
$ibuf[2 + 1] = EIBConnection: :packb((PAR(dest)) & 0xff);
$ibuf[0] = EIBConnection: :packb((0x0040 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0040) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIB_M_WriteIndividualAddress"."_complete";
		return 0;
	} public function EIB_M_WriteIndividualAddress(PAR(dest)) {
		if ($this->EIB_M_WriteIndividualAddress_async(PAR(dest)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIBOpenBusmonitor_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) == 0x0001) {
	$this->errno = self: :EBUSY;
			return -1;
} if            (((EIBConnection: :                upack(substr($this->data, 0, 2), "n"))) != 0x0010 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		} return 0;
	}
	public function EIBOpenBusmonitor_async() {
		$head = array();
		for ($i = 0; $i < 2; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[0] = EIBConnection: :packb((0x0010 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0010) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIBOpenBusmonitor"."_complete";
		return 0;
	} public function EIBOpenBusmonitor() {
		if ($this->EIBOpenBusmonitor_async() == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIBOpenBusmonitorText_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) == 0x0001) {
	$this->errno = self: :EBUSY;
			return -1;
} if            (((EIBConnection: :                upack(substr($this->data, 0, 2), "n"))) != 0x0011 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		} return 0;
	}
	public function EIBOpenBusmonitorText_async() {
		$head = array();
		for ($i = 0; $i < 2; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[0] = EIBConnection: :packb((0x0011 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0011) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIBOpenBusmonitorText"."_complete";
		return 0;
	} public function EIBOpenBusmonitorText() {
		if ($this->EIBOpenBusmonitorText_async() == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIBOpen_GroupSocket_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0026 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               return 0;
	}
	public function EIBOpen_GroupSocket_async(PAR(write_only)) {
		$head = array();
		for ($i = 0; $i < 5; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[4] = EIBConnection: :packb((PAR(write_only)) ? 0xff : 0);
$ibuf[0] = EIBConnection: :packb((0x0026 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0026) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIBOpen_GroupSocket"."_complete";
		return 0;
	} public function EIBOpen_GroupSocket(PAR(write_only)) {
		if ($this->EIBOpen_GroupSocket_async(PAR(write_only)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIBOpenT_Broadcast_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0023 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               return 0;
	}
	public function EIBOpenT_Broadcast_async(PAR(write_only)) {
		$head = array();
		for ($i = 0; $i < 5; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[4] = EIBConnection: :packb((PAR(write_only)) ? 0xff : 0);
$ibuf[0] = EIBConnection: :packb((0x0023 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0023) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIBOpenT_Broadcast"."_complete";
		return 0;
	} public function EIBOpenT_Broadcast(PAR(write_only)) {
		if ($this->EIBOpenT_Broadcast_async(PAR(write_only)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIBOpenT_Connection_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0020 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               return 0;
	}
	public function EIBOpenT_Connection_async(PAR(dest)) {
		$head = array();
		for ($i = 0; $i < 5; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[2] = EIBConnection: :packb((PAR(dest) >> 8) & 0xff);
$ibuf[2 + 1] = EIBConnection: :packb((PAR(dest)) & 0xff);
$ibuf[0] = EIBConnection: :packb((0x0020 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0020) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIBOpenT_Connection"."_complete";
		return 0;
	} public function EIBOpenT_Connection(PAR(dest)) {
		if ($this->EIBOpenT_Connection_async(PAR(dest)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIBOpenT_Group_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0022 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               return 0;
	}
	public function EIBOpenT_Group_async(PAR(dest), PAR(write_only)) {
		$head = array();
		for ($i = 0; $i < 5; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[2] = EIBConnection: :packb((PAR(dest) >> 8) & 0xff);
$ibuf[2 + 1] = EIBConnection: :packb((PAR(dest)) & 0xff);
$ibuf[4] = EIBConnection: :packb((PAR(write_only)) ? 0xff : 0);
$ibuf[0] = EIBConnection: :packb((0x0022 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0022) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIBOpenT_Group"."_complete";
		return 0;
	} public function EIBOpenT_Group(PAR(dest), PAR(write_only)) {
		if ($this->EIBOpenT_Group_async(PAR(dest), PAR(write_only)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIBOpenT_Individual_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0021 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               return 0;
	}
	public function EIBOpenT_Individual_async(PAR(dest), PAR(write_only)) {
		$head = array();
		for ($i = 0; $i < 5; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[2] = EIBConnection: :packb((PAR(dest) >> 8) & 0xff);
$ibuf[2 + 1] = EIBConnection: :packb((PAR(dest)) & 0xff);
$ibuf[4] = EIBConnection: :packb((PAR(write_only)) ? 0xff : 0);
$ibuf[0] = EIBConnection: :packb((0x0021 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0021) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIBOpenT_Individual"."_complete";
		return 0;
	} public function EIBOpenT_Individual(PAR(dest), PAR(write_only)) {
		if ($this->EIBOpenT_Individual_async(PAR(dest), PAR(write_only)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIBOpenT_TPDU_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0024 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               return 0;
	}
	public function EIBOpenT_TPDU_async(PAR(src)) {
		$head = array();
		for ($i = 0; $i < 5; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[2] = EIBConnection: :packb((PAR(src) >> 8) & 0xff);
$ibuf[2 + 1] = EIBConnection: :packb((PAR(src)) & 0xff);
$ibuf[0] = EIBConnection: :packb((0x0024 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0024) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIBOpenT_TPDU"."_complete";
		return 0;
	} public function EIBOpenT_TPDU(PAR(src)) {
		if ($this->EIBOpenT_TPDU_async(PAR(src)) == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIBOpenVBusmonitor_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) == 0x0001) {
	$this->errno = self: :EBUSY;
			return -1;
} if            (((EIBConnection: :                upack(substr($this->data, 0, 2), "n"))) != 0x0012 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		} return 0;
	}
	public function EIBOpenVBusmonitor_async() {
		$head = array();
		for ($i = 0; $i < 2; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[0] = EIBConnection: :packb((0x0012 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0012) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIBOpenVBusmonitor"."_complete";
		return 0;
	} public function EIBOpenVBusmonitor() {
		if ($this->EIBOpenVBusmonitor_async() == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIBOpenVBusmonitorText_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) == 0x0001) {
	$this->errno = self: :EBUSY;
			return -1;
} if            (((EIBConnection: :                upack(substr($this->data, 0, 2), "n"))) != 0x0013 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		} return 0;
	}
	public function EIBOpenVBusmonitorText_async() {
		$head = array();
		for ($i = 0; $i < 2; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[0] = EIBConnection: :packb((0x0013 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0013) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIBOpenVBusmonitorText"."_complete";
		return 0;
	} public function EIBOpenVBusmonitorText() {
		if ($this->EIBOpenVBusmonitorText_async() == -1)
			return -1;
		return $this->EIBComplete();
	}

	private function EIBReset_complete() {
		if ($this->_EIB_GetRequest() == -1)
			return -1;
if (((EIBConnection: :upack(substr($this->data, 0, 2), "n"))) != 0x0004 || strlen($this->data) < 2) {
	$this->errno = self: :ECONNRESET;
			return -1;
		}               return 0;
	}
	public function EIBReset_async() {
		$head = array();
		for ($i = 0; $i < 2; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[0] = EIBConnection: :packb((0x0004 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0004) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		$this->complete = "EIBReset"."_complete";
		return 0;
	} public function EIBReset() {
		if ($this->EIBReset_async() == -1)
			return -1;
		return $this->EIBComplete();
	}

	public function EIBSendAPDU(PAR(data)) {
		$head = array();
		for ($i = 0; $i < 2; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
		if (strlen(PAR(data)) < 2) {
	$this->errno = self: :EINVAL;
			return -1;
		}               $this->sendlen = strlen(PAR(data));
		for ($i = 0; $i < strlen(PAR(data)); $i++)
			$ibuf[] = substr(PAR(data), $i, 1);
$ibuf[0] = EIBConnection: :packb((0x0025 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0025) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		return $this->sendlen;
	}

	public function EIBSendGroup(PAR(dest), PAR(data)) {
		$head = array();
		for ($i = 0; $i < 4; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[2] = EIBConnection: :packb((PAR(dest) >> 8) & 0xff);
$ibuf[2 + 1] = EIBConnection: :packb((PAR(dest)) & 0xff);
		if (strlen(PAR(data)) < 2) {
	$this->errno = self: :EINVAL;
			return -1;
		}               $this->sendlen = strlen(PAR(data));
		for ($i = 0; $i < strlen(PAR(data)); $i++)
			$ibuf[] = substr(PAR(data), $i, 1);
$ibuf[0] = EIBConnection: :packb((0x0027 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0027) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		return $this->sendlen;
	}

	public function EIBSendTPDU(PAR(dest), PAR(data)) {
		$head = array();
		for ($i = 0; $i < 4; $i++)
			$head[$i] = " ";
		$ibuf =& $head;
$ibuf[2] = EIBConnection: :packb((PAR(dest) >> 8) & 0xff);
$ibuf[2 + 1] = EIBConnection: :packb((PAR(dest)) & 0xff);
		if (strlen(PAR(data)) < 2) {
	$this->errno = self: :EINVAL;
			return -1;
		}               $this->sendlen = strlen(PAR(data));
		for ($i = 0; $i < strlen(PAR(data)); $i++)
			$ibuf[] = substr(PAR(data), $i, 1);
$ibuf[0] = EIBConnection: :packb((0x0025 >> 8) & 0xff);
$ibuf[1] = EIBConnection: :packb((0x0025) & 0xff);
		if ($this->_EIB_SendRequest(implode("", $ibuf)) == -1)
			return -1;
		return $this->sendlen;
	}
	protected static function upack($data, $type) {
		$res = unpack($type."val", $data);
		return $res["val"];
	}
	protected static function packb($data) {
		return pack("C", $data);
	}
}
?>
